const morgan=require('morgan');
const express=require('express');
const router=require('express-promise-router')();
const oracledb=require('oracledb');
oracledb.outFormat=oracledb.OBJECT;
const cors=require('cors');





let connection=undefined;
async function db_query(query,params)
{
    if(connection==undefined)
    {
        connection=await oracledb.getConnection({
            user:'hr',
            password:'hr',
            connectionString:'localhost/ORCL'

        })
        try{
            let result=await connection.execute(query,params);
            return result.rows;
        }
        catch(err)
        {
            console.log(err);
        }
    }
}





router.get('/employee/all',async function(req,res,next){
    console.log("we are here");
    const query=`SELECT * FROM EMPLOYEES`;
    const params=[];
    const result=await db_query(query,params);
    res.status(200).json(result);
})


const app=express();
app.use(cors());
app.use('*',cors());
app.use(express.json());
app.use(morgan('dev'));
app.use(router);

app.listen(4321,()=>{
    console.log('server is listening at port 4321');
})

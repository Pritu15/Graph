const express = require('express');
const morgan = require('morgan');
//const oracledb=require('oracledb');
//const Blog=require('./models/blog');
const oracledb = require('./Database/dbBegining.js');


//express app
const authRouter = express.Router();
const userRouter = express.Router();

const app = express();
oracledb.Starting();
app.listen(3000);
const sql = `SELECT * 
FROM EMPLOYEES`;
const binds = {};
//const result = oracledb.execute(sql, binds);

//connect to DataBase
// oracledb.getConnection({
//     user:'hr',
//     password:'hr',
//     connectionString:'localhost/ORCL'

// })
// .then((result)=>{app.listen(3000)})
// .catch((err)=>{console.log(err)});
// try{
//     let result=await connection.execute(query,params);
//     return result.rows;
// }
// catch(err)
// {
//     console.log(err);
// }


//register view engine
app.set('view engine', 'ejs');


//listen for requests

//app.listen(3000);


//middleware & static files
app.use(express.static('public'));
app.use(morgan('dev'));
app.use(express.json());
app.use('/auth', authRouter);
app.use('/user', userRouter);

authRouter
    .route('/signup')
    .get(getSignUp)
    .post(postSignUp)
    .delete(deleteuser);
userRouter
    .route('/login')
    .get(getlogIn)
    .post(postlogIn);

userRouter
.route('/login/mainwebsite')
.get(getMainPage)
.post(postMainPage)
.delete();
userRouter
.route('/login/mainwebsite/profile')
.get(getProfilePage)
.post()
.delete();
async function postMainPage(req,res)
{
    let {searchInput,searchType}=req.body;
    let user=await oracledb.db_queryforSearchDetails(searchInput,searchType);
    // res.render('Profile_user', { user });
    res.json({
        message: "user Profile data",
        data: user

    });

}


 async function getProfilePage(req,res)
{
    let {email}=req.body;
    let user=await oracledb.db_queryforUserDetails(email);
    res.render('Profile_user', { user });

}

function getMainPage(req,res)
{
    res.sendFile('./views/Project.html', { root: __dirname });

}


function getlogIn(req, res) {
    res.sendFile('./views/log_in.html', { root: __dirname });

}
 async function postlogIn(req, res) {
    let obj = req.body;
    let {userType, email,password } = req.body;
     console.log({ userType,email,password });
    console.log('I am here');
    //console.log(obj);
    //const binds={email,password};
    let temp= await oracledb.db_queryforLogin(userType,email,password);
    console.log(temp);
    if(temp===1)
    {
        console.log("done and dusted");
    }

    //const binds = { name: name,email: email,password: password }; // Replace 'user@example.com' with the actual email value
    //oracledb.db_querySignup(binds);

    res.json({
        message: "user Logged In",
        data: temp

    });

}


function getSignUp(req, res) {
    res.render('signup', { title: 'SignUP' });
    //res.sendFile('./views/sign_up_for_user.html', { root: __dirname });

}
async function postSignUp(req, res) {
    let obj = req.body;
    let { email, name, password ,dateOfBirth,address,phoneNumber} = req.body;
    // console.log({ email, name, password });
    console.log('I am here');
    console.log(obj);

    const binds = { name: name, email: email, password: password ,dateOfBirth: dateOfBirth,address: address,phoneNumber: phoneNumber}; // Replace 'user@example.com' with the actual email value
    console.log(binds);
    let flag=await oracledb.db_querySignup(binds);
    // if(flag===404)
    // {
    //     console.log(404);
    //     res.json({
    //         message: "user what are u doin?",
    //         data: flag
    
    //     });

    // }

    res.json({
        message: "user signed up",
        data: flag

    });
}

function deleteuser(req, res) { }

// app.use((req,res,next)=>{
//     console.log('new request made:');
//     console.log('host: ',req.hostname);
//     console.log('path',req.path);
//     console.log('method: ',req.method);
//     next();
// })


//oracledb routes
app.get('/add-blog', (req, res) => {
    const blog = new Blog();

})
app.get('/', (req, res) => {
    //res.send('<p>Home Page</p>')
    res.sendFile('./views/FirstPage.html', { root: __dirname });
    const blogs = [
        { title: 'yashi finds eggs', snippet: 'Lorem ipsum dolor sit amet consectetur' },
        { title: 'Mario finds stars', snippet: 'Lorem ipsum dolor sit amet consectetur' },
        { title: 'How to defeat browser', snippet: 'Lorem ipsum dolor sit amet consectetur' },
    ];
    // res.render('index', { title: 'Home', blogs: blogs });
})
// app.get('/login',(req,res)=>{
//     res.sendFile('./views/log_in.html',{root:__dirname});

// })

app.get('/about', (req, res) => {
    //res.render('books', { title: 'BOOK_DETAIL' });
   // res.sendFile('website.html',{root:__dirname});
    //res.render('about', { title: 'About' });
})

app.get('/blogs/create', (req, res) => {
    res.render('create', { title: 'Create a new Blog' });
})



//REdirects

app.get('/about-us', (req, res) => {
    // res.redirect('/about');
    res.status(404).render('about');
})


//404 page
app.use((req, res) => {
    //res.status(404).sendFile('./views/404.html',{root:__dirname});
    res.render('404', { title: '404' });

})

const express = require('express');
const oracledb = require('oracledb');

oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
oracledb.autoCommit = true;

//Connecting databse 
const db_link = {
    user: "Project",
    password: "test",  // mypw contains the hr schema password
    connectString: "localhost/ORCLPDB",
    poolIncrement: 1,
    poolMax: 15,
    poolMin: 4,
    poolAlias: 'mypool'
};

// DB pool creation function
const Starting = async () => {
    oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
    try {
        await oracledb.createPool(db_link);
        console.log("Database pool created...");
    } catch (err) {
        console.log(`Found error : ${err.message} while creating db pool...`);
    }

}
// Pool closing Function
const close = async () => {
    console.log('Closing db...');
    try {
        await oracledb.getPool().close(0);
        console.log('DB closed successfully...');
    } catch (err) {
        console.log(`Found error : ${err.message + '\n'} while closing db...`);
    }
}

// SQL execution function
const execute = async (sql, binds) => {
    console.log("Sql statemnt passed with " + sql + " binds " + binds + "\n");

    let connection;
    try {
        connection = await oracledb.getConnection(mypool);
        resultQuery = await connection.execute(sql, binds);

        //console.log(resultQuery.rows);
        console.log("SQL query Result returned Successfully" + '\n');
        console.log(resultQuery.rows);

        return resultQuery.rows;                                // returns data trom DATABASE table

    } catch (err) {
        console.log(`Found error : ${err.message} while excecuting SQL QUERY`);
    } finally {
        if (connection) {
            try {
                await connection.close();           // Put the connection back in the pool
            } catch (err) {
                console.log(`Found error : ${err.message} while closing Connection after SQL Query`);
            }
        }
    }
}


const db_queryforLogin = async (userType, email, password) => {
    //console.log(email,password);
    let sql = undefined;
    if (userType === 'customer') {
        sql = `SELECT COUNT(*) AS userCount
    FROM CUSTOMERS
    WHERE EMAIL = :email AND PASSWORD_HASH = :password`;


    }
    else {
        sql = `SELECT COUNT(*) AS userCount
    FROM OUTLET
    WHERE EMAIL = :email AND PASSWORD_HASH = :password`;
    }
    //const 
    const binds = { email, password };
    //console.log("Sql statemnt passed with " + sql + " binds " + binds + "\n");

    let connection;
    try {
        connection = await oracledb.getConnection(db_link);
        const result = await connection.execute(sql, binds);
        const userCount = result.rows[0].USERCOUNT; // Replace 'USERCOUNT' with the actual column name
        console.log(userCount);
        if (userCount === 1) {
            console.log('User count:', userCount);
        }


        //console.log(resultQuery.rows);
        console.log("SQL query Result returned Successfully" + '\n');
        //console.log(result.rows);
        // console.log(result.rows[0].OUT_FORMAT_OBJECT);

        return userCount;                                // returns data trom DATABASE table

    } catch (err) {
        console.log(`Found error : ${err.message} while excecuting SQL QUERY`);
    } finally {
        if (connection) {
            try {
                await connection.close();           // Put the connection back in the pool
            } catch (err) {
                console.log(`Found error : ${err.message} while closing Connection after SQL Query`);
            }
        }
    }
}
const db_queryforUserDetails = async (email) => {

    const sql = `SELECT C.CUSTOMER_NAME,C.ADDRESS,C.EMAIL,C.PHONE_NO,C.DATE_OF_BIRTH
    FROM CUSTOMERS C
    WHERE EMAIL = :email `;
    const binds = { email };
    let connection;
    try {
        connection = await oracledb.getConnection(db_link);
        const result = await connection.execute(sql, binds);
        // const userCount = result.rows[0].USERCOUNT;
        console.log(result.rows[0]);
        console.log("SQL query Result returned Successfully" + '\n');
        return result.rows[0];                                // returns data trom DATABASE table

    } catch (err) {
        console.log(`Found error : ${err.message} while excecuting SQL QUERY`);
    } finally {
        if (connection) {
            try {
                await connection.close();           // Put the connection back in the pool
            } catch (err) {
                console.log(`Found error : ${err.message} while closing Connection after SQL Query`);
            }
        }
    }
}
const db_queryforSearchDetails = async (searchInput, searchType) => {
    let sql = undefined;

    if (searchType === 'Search_by_book_name') {
        sql = `SELECT B.BOOK_NAME, B.PRICE, B.EDITION, G.GENRE_NAME, A.AUTHOR_NAME
           FROM GENRE G
           JOIN BOOKS B USING (GENRE_ID)
           JOIN WRITES W USING (BOOK_ID)
           JOIN AUTHOR A USING (AUTHOR_ID)
           WHERE UPPER(B.BOOK_NAME) = UPPER(:searchInput)`;
    }
    else if (searchType === 'Search_by_Author_name') {
        sql = `SELECT B.BOOK_NAME, B.PRICE, B.EDITION, A.AUTHOR_NAME
           FROM BOOKS B
           JOIN WRITES W USING (BOOK_ID)
           JOIN AUTHOR A ON W.AUTHOR_ID = A.AUTHOR_ID
           WHERE UPPER(A.AUTHOR_NAME) = UPPER(:searchInput)`;
    }
    else if (searchType === 'Search_by_Genre') {
        sql = `SELECT B.BOOK_NAME, A.AUTHOR_NAME, B.PRICE, G.GENRE_NAME,b.EDITION
           FROM BOOKS B 
           JOIN WRITES W USING (BOOK_ID)
           JOIN AUTHOR A USING (AUTHOR_ID)
           JOIN GENRE G USING (GENRE_ID)
           WHERE UPPER(G.GENRE_NAME) = UPPER(:searchInput)`;
    }

    const binds = { searchInput };





    let connection;
    try {
        connection = await oracledb.getConnection(db_link);
        const result = await connection.execute(sql, binds);
        // const userCount = result.rows[0].USERCOUNT;
        console.log(result.rows);
        console.log("SQL query Result returned Successfully" + '\n');
        return result.rows;                                // returns data trom DATABASE table

    } catch (err) {
        console.log(`Found error : ${err.message} while excecuting SQL QUERY`);
    } finally {
        if (connection) {
            try {
                await connection.close();           // Put the connection back in the pool
            } catch (err) {
                console.log(`Found error : ${err.message} while closing Connection after SQL Query`);
            }
        }
    }
}



const db_querySignup = async (binds) => {
    console.log(binds);
    const sql = `INSERT INTO CUSTOMERS (CUSTOMER_NAME,ADDRESS,EMAIL,PHONE_NO,DATE_OF_BIRTH,PASSWORD_HASH) VALUES(:name,:address,:email,:phoneNumber,TO_DATE(:dateofBirth, 'YYYY-MM-DD'),:password)`;

    let connection;
    try {
        connection = await oracledb.getConnection(db_link);
        const result = await connection.execute(sql, binds, { autoCommit: true });
        // const userCount = result.rows[0].USERCOUNT; // Replace 'USERCOUNT' with the actual column name
        // console.log(userCount);
        // if(userCount==1)
        // {
        //     console.log('User count:', userCount);
        // }


        //console.log(resultQuery.rows);
        console.log("SQL query Result returned Successfully" + '\n');
        //console.log(result.rows);

        // return result.rows;
        return 200;                                // returns data trom DATABASE table

    } catch (err) {

        console.log(`Found error : ${err.message} while excecuting SQL QUERY`);
        return 404;
    } finally {
        if (connection) {
            try {
                await connection.close();           // Put the connection back in the pool
            } catch (err) {
                console.log(`Found error : ${err.message} while closing Connection after SQL Query`);
            }
        }
    }
}


const db_queryDeleteUser = async (binds) => {
    const sql = `INSERT INTO USERS (NAME,EMAIL,PASSWORD) VALUES(:name,:email,:password)`;
    //console.log("Sql statemnt passed with " + sql + " binds " + binds + "\n");

    let connection;
    try {
        connection = await oracledb.getConnection({
            user: 'hr',
            password: 'hr',
            connectionString: 'localhost/ORCL'

        });
        const result = await connection.execute(sql, binds, { autoCommit: true });
        // const userCount = result.rows[0].USERCOUNT; // Replace 'USERCOUNT' with the actual column name
        // console.log(userCount);
        // if(userCount==1)
        // {
        //     console.log('User count:', userCount);
        // }


        //console.log(resultQuery.rows);
        console.log("SQL query Result returned Successfully" + '\n');
        //console.log(result.rows);

        // return result.rows;                                // returns data trom DATABASE table

    } catch (err) {
        console.log(`Found error : ${err.message} while excecuting SQL QUERY`);
    } finally {
        if (connection) {
            try {
                await connection.close();           // Put the connection back in the pool
            } catch (err) {
                console.log(`Found error : ${err.message} while closing Connection after SQL Query`);
            }
        }
    }
}



module.exports = {
    Starting
    , close
    , execute
    , db_queryforLogin
    , db_querySignup
    , db_queryforUserDetails
    , db_queryforSearchDetails
};
const oracledb=require('oracledb');



const blogShema= `
CREATE TABLE blogSchema(
    TITLE VARCHAR2(30) NOT NULL,
    Snippet VARCHAR2(255) NOT NULL,
    BODY VARCHAR(255) NOT NULL,
)
`;
//const blogShema;

const Blog=oracledb.model('Blog',blogShema);
module.exports=Blog;